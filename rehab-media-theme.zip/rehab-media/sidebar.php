<aside class="sidebar">
  <!-- CTA виджет -->
  <div class="sidebar-widget">
    <div class="sidebar-cta">
      <div class="cta-eyebrow">Rehab.You</div>
      <div class="cta-title">Массаж в Москве — рядом с вами</div>
      <div class="cta-price">от <strong>5 500 ₽</strong> первый сеанс</div>
      <a href="https://n1276048.yclients.com" target="_blank" class="cta-btn">Записаться онлайн</a>
    </div>
  </div>

  <!-- Квиз -->
  <div class="sidebar-widget">
    <div class="sidebar-quiz">
      <div class="quiz-title">Какой массаж подходит именно вам?</div>
      <div class="quiz-desc">3 вопроса — и мы подберём формат под ваш запрос</div>
      <a href="https://rehabyou.site/#packages" class="quiz-btn">Пройти тест</a>
    </div>
  </div>

  <!-- Популярные посты -->
  <div class="sidebar-widget">
    <div class="widget-title">Читают сейчас</div>
    <?php
    $popular = new WP_Query(['posts_per_page' => 4, 'orderby' => 'comment_count', 'order' => 'DESC']);
    while($popular->have_posts()): $popular->the_post(); ?>
    <div class="popular-post">
      <?php if(has_post_thumbnail()): ?>
      <div class="popular-post-img">
        <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('thumbnail'); ?></a>
      </div>
      <?php endif; ?>
      <div>
        <a href="<?php the_permalink(); ?>" class="popular-post-title"><?php the_title(); ?></a>
        <div class="popular-post-meta"><?php echo get_the_date('d.m.Y'); ?></div>
      </div>
    </div>
    <?php endwhile; wp_reset_postdata(); ?>
  </div>

  <!-- Рубрики -->
  <div class="sidebar-widget">
    <div class="widget-title">Рубрики</div>
    <ul class="cat-list">
      <?php $cats = get_categories(['hide_empty' => false]);
      foreach($cats as $cat): ?>
      <li>
        <a href="<?php echo get_category_link($cat->term_id); ?>">
          <?php echo esc_html($cat->name); ?>
          <span class="cat-count"><?php echo $cat->count; ?></span>
        </a>
      </li>
      <?php endforeach; ?>
    </ul>
  </div>
</aside>
