<aside class="sidebar">
  <!-- CTA -->
  <div class="sidebar-widget">
    <div class="sidebar-cta">
      <div class="cta-eyebrow">Rehab.You · Москва</div>
      <div class="cta-title">Массаж рядом с вами — два клуба в Москве</div>
      <div class="cta-price">от <strong>5 500 ₽</strong> первый сеанс</div>
      <a href="https://n1276048.yclients.com" target="_blank" class="cta-btn">Записаться онлайн</a>
    </div>
  </div>

  <!-- Telegram -->
  <div class="sidebar-widget">
    <div class="sidebar-tg">
      <div class="tg-title">Читайте нас в Telegram</div>
      <div class="tg-desc">Советы, новые статьи и акции Rehab.You — первыми</div>
      <a href="https://t.me/+VMr5mZEITjJhMWQ6" target="_blank" class="tg-link">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12l-6.871 4.326-2.962-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.537-.194 1.006.131.833.941z"/></svg>
        Подписаться
      </a>
    </div>
  </div>

  <!-- Приложение -->
  <div class="sidebar-widget">
    <div class="sidebar-app">
      <div class="app-title">Rehab.You App — скоро</div>
      <div class="app-desc">Запись, история сеансов и журнал в одном приложении</div>
      <a href="#" class="app-btn">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9V8h2v8zm4 0h-2V8h2v8z"/></svg>
        Узнать первым
      </a>
    </div>
  </div>

  <!-- Рубрики -->
  <div class="sidebar-widget">
    <div class="widget-title">Рубрики</div>
    <ul class="cat-list">
      <?php $cats = get_categories(['hide_empty' => false, 'exclude' => get_cat_ID('Uncategorized')]);
      foreach($cats as $cat): ?>
      <li>
        <a href="<?php echo get_category_link($cat->term_id); ?>">
          <?php echo esc_html($cat->name); ?>
          <span class="cat-count"><?php echo $cat->count; ?></span>
        </a>
      </li>
      <?php endforeach; ?>
    </ul>
  </div>
</aside>
