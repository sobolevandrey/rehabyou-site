<aside class="sidebar">
  <!-- CTA — без цены -->
  <div class="sidebar-widget">
    <div class="sidebar-cta">
      <div class="cta-eyebrow">Rehab.You · Москва</div>
      <div class="cta-title">Массаж рядом с вами — два клуба в Москве</div>
      <div style="font-size:13px;color:rgba(255,255,255,0.35);margin-bottom:18px;">Классический, спортивный, расслабляющий, антицеллюлитный</div>
      <a href="https://n1276048.yclients.com" target="_blank" class="cta-btn">Записаться онлайн</a>
    </div>
  </div>

  <!-- Приложение — redesigned -->
  <div class="sidebar-widget">
    <div class="sidebar-app">
      <div class="app-badge">Уже доступно</div>
      <div class="app-title">Rehab.You App</div>
      <div class="app-desc">Запись на массаж, история сеансов и журнал — в одном приложении</div>
      <div class="app-btns">
        <a href="#" class="app-store-btn">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/></svg>
          <div><span class="app-store-label">Скачать в</span>App Store</div>
        </a>
        <a href="#" class="app-store-btn">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M3.18 23.76c.3.17.65.19.96.05l12.82-7.4-2.8-2.8-10.98 10.15zM.44 1.6C.17 1.94.01 2.42.01 3.04v17.92c0 .62.16 1.1.43 1.44l.07.07 10.04-10.03v-.24L.51 1.53l-.07.07zM20.54 10.5l-2.74-1.58-3.15 3.14 3.15 3.14 2.77-1.6c.79-.46.79-1.6-.03-2.1zM3.18.24L16 7.64l-2.8 2.8L.36.29c.31-.14.66-.12.96.05l2.86 1.9z"/></svg>
          <div><span class="app-store-label">Скачать в</span>Google Play</div>
        </a>
      </div>
    </div>
  </div>

  <!-- Рубрики -->
  <div class="sidebar-widget">
    <div class="widget-title">Рубрики</div>
    <ul class="cat-list">
      <?php $cats = get_categories(['hide_empty' => false, 'exclude' => get_cat_ID('Uncategorized')]);
      foreach($cats as $cat): ?>
      <li>
        <a href="<?php echo get_category_link($cat->term_id); ?>">
          <?php echo esc_html($cat->name); ?>
          <span class="cat-count"><?php echo $cat->count; ?></span>
        </a>
      </li>
      <?php endforeach; ?>
    </ul>
  </div>
</aside>
