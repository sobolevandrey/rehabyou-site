<?php
function rehab_media_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form','comment-form','gallery','caption']);
    register_nav_menus(['primary' => 'Основное меню']);
}
add_action('after_setup_theme', 'rehab_media_setup');

function rehab_media_scripts() {
    wp_enqueue_style('rehab-media-style', get_stylesheet_uri(), [], '2.0');
}
add_action('wp_enqueue_scripts', 'rehab_media_scripts');

// Убираем uncategorized из списков
function hide_uncategorized($query) {
    if (!is_admin() && $query->is_main_query()) {
        $uncategorized = get_cat_ID('Uncategorized');
        if ($uncategorized) {
            $query->set('cat', '-' . $uncategorized);
        }
    }
}
add_action('pre_get_posts', 'hide_uncategorized');

// Excerpt
function rehab_excerpt_length() { return 18; }
add_filter('excerpt_length', 'rehab_excerpt_length');
function rehab_excerpt_more() { return '...'; }
add_filter('excerpt_more', 'rehab_excerpt_more');

// Комментарии — разрешаем
function rehab_comments_setup() {
    add_theme_support('automatic-feed-links');
}
add_action('after_setup_theme', 'rehab_comments_setup');
