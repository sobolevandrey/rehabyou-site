<?php
function rehab_media_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'comment-form', 'gallery', 'caption']);
    add_theme_support('custom-logo');
    register_nav_menus(['primary' => 'Основное меню']);
}
add_action('after_setup_theme', 'rehab_media_setup');

function rehab_media_widgets_init() {
    register_sidebar(['id' => 'sidebar-1', 'name' => 'Боковая панель',
        'before_widget' => '<div class="sidebar-widget">', 'after_widget' => '</div>',
        'before_title' => '<div class="widget-title">', 'after_title' => '</div>',
    ]);
}
add_action('widgets_init', 'rehab_media_widgets_init');

function rehab_media_scripts() {
    wp_enqueue_style('rehab-media-style', get_stylesheet_uri(), [], '1.0');
}
add_action('wp_enqueue_scripts', 'rehab_media_scripts');

// Excerpt length
function rehab_excerpt_length() { return 20; }
add_filter('excerpt_length', 'rehab_excerpt_length');
function rehab_excerpt_more() { return '...'; }
add_filter('excerpt_more', 'rehab_excerpt_more');
