<footer class="site-footer">
  <div class="footer-main">
    <div>
      <div class="footer-logo-text">REHAB<span class="dot">.</span>YOU МЕДИА</div>
      <div class="footer-desc">Журнал об активной жизни, здоровье и красоте в Москве</div>
      <div class="footer-social">
        <a href="https://t.me/+VMr5mZEITjJhMWQ6" target="_blank"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12l-6.871 4.326-2.962-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.537-.194 1.006.131.833.941z"/></svg></a>
        <a href="https://instagram.com/rehab.you" target="_blank"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg></a>
        <a href="https://vk.com/rehab_you" target="_blank"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M15.684 0H8.316C1.592 0 0 1.592 0 8.316v7.368C0 22.408 1.592 24 8.316 24h7.368C22.408 24 24 22.408 24 15.684V8.316C24 1.592 22.408 0 15.684 0zm3.692 17.123h-1.744c-.66 0-.862-.525-2.049-1.714-1.033-1.01-1.49-.9-1.49.426v1.297c0 .336-.107.426-1.31.426-1.937 0-4.091-1.17-5.604-3.35-2.274-3.21-2.9-5.612-2.9-6.108 0-.233.082-.45.45-.45h1.744c.336 0 .466.155.598.52.66 1.896 1.76 3.56 2.214 3.56.172 0 .25-.08.25-.52V9.34c-.05-.934-.548-1.013-.548-1.348 0-.16.13-.32.336-.32h2.743c.285 0 .388.155.388.492v2.643c0 .285.13.385.212.385.172 0 .315-.1.63-.414 1.953-2.185 3.35-5.54 3.35-5.54.09-.213.242-.4.578-.4h1.745c.523 0 .638.268.523.633-.213.955-2.296 3.9-2.296 3.9-.182.293-.246.42 0 .744.173.232.738.7 1.116 1.123.69.777 1.22 1.43 1.362 1.882.14.45-.082.68-.517.68z"/></svg></a>
      </div>
    </div>
    <div class="footer-col">
      <div class="footer-col-title">Рубрики</div>
      <ul>
        <?php $cats=get_categories(['hide_empty'=>false,'exclude'=>get_cat_ID('Uncategorized')]);
        foreach($cats as $cat): ?>
        <li><a href="<?php echo get_category_link($cat->term_id); ?>"><?php echo esc_html($cat->name); ?></a></li>
        <?php endforeach; ?>
      </ul>
    </div>
    <div class="footer-col">
      <div class="footer-col-title">Rehab.You</div>
      <ul>
        <li><a href="https://rehabyou.site">Основной сайт</a></li>
        <li><a href="https://n1276048.yclients.com" target="_blank">Записаться на массаж</a></li>
        <li><a href="https://rehabyou.site/massage/classic/">Классический массаж</a></li>
        <li><a href="https://rehabyou.site/massage/sport/">Спортивный массаж</a></li>
        <li><a href="https://rehabyou.site/massage/relax/">Расслабляющий</a></li>
        <li><a href="https://rehabyou.site/#locations">Адреса клубов</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <div class="footer-col-title">Приложение</div>
      <div class="footer-app-block">
        <div class="footer-app-title">Rehab.You App</div>
        <div class="footer-app-sub">Запись, история сеансов и журнал в одном приложении</div>
        <div class="footer-app-btns">
          <a href="#" class="footer-app-btn"><svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/></svg> App Store</a>
          <a href="#" class="footer-app-btn"><svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M3.18 23.76c.3.17.65.19.96.05l12.82-7.4-2.8-2.8-10.98 10.15zM.44 1.6C.17 1.94.01 2.42.01 3.04v17.92c0 .62.16 1.1.43 1.44l.07.07 10.04-10.03v-.24L.51 1.53l-.07.07zM20.54 10.5l-2.74-1.58-3.15 3.14 3.15 3.14 2.77-1.6c.79-.46.79-1.6-.03-2.1zM3.18.24L16 7.64l-2.8 2.8L.36.29c.31-.14.66-.12.96.05l2.86 1.9z"/></svg> Google Play</a>
        </div>
      </div>
    </div>
  </div>
  <div class="footer-bottom">
    <div class="footer-bottom-inner">
      <div class="footer-copy">&copy; <?php echo date('Y'); ?> Rehab.You Media. Все материалы носят информационный характер.</div>
      <div class="footer-legal">
        <a href="https://rehabyou.site/privacy/">Конфиденциальность</a>
        <a href="https://rehabyou.site/oferta/">Публичная оферта</a>
      </div>
    </div>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
