<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-logo">REHAB<span>.</span>YOU MEDIA</div>
    <div class="footer-links">
      <a href="https://rehabyou.site">Основной сайт</a>
      <a href="https://n1276048.yclients.com" target="_blank">Записаться</a>
      <a href="<?php echo home_url('/'); ?>">Журнал</a>
    </div>
  </div>
  <div class="footer-bottom">
    © <?php echo date('Y'); ?> Rehab.You Media. Все материалы информационного характера.
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
