<?php get_header(); ?>
<div class="site-main">
  <main class="main-content">
    <div style="margin-bottom:32px;">
      <div class="post-cat" style="font-size:10px;margin-bottom:8px;"><?php single_cat_title('Рубрика: '); ?></div>
      <?php if(category_description()): ?>
      <p style="color:var(--gray);font-size:14px;"><?php echo category_description(); ?></p>
      <?php endif; ?>
    </div>
    <div class="posts-grid">
    <?php while(have_posts()): the_post(); ?>
    <div class="post-card">
      <?php if(has_post_thumbnail()): ?>
      <div class="post-card-img">
        <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('medium_large'); ?></a>
      </div>
      <?php endif; ?>
      <div class="post-card-body">
        <?php $cats = get_the_category(); if($cats): ?>
        <div class="post-meta">
          <a href="<?php echo get_category_link($cats[0]->term_id); ?>" class="cat-link"><?php echo esc_html($cats[0]->name); ?></a>
          <span><?php echo get_the_date('d.m.Y'); ?></span>
        </div>
        <?php endif; ?>
        <a href="<?php the_permalink(); ?>" class="post-title"><?php the_title(); ?></a>
        <div class="post-excerpt"><?php the_excerpt(); ?></div>
      </div>
    </div>
    <?php endwhile; ?>
    </div>
    <?php the_posts_navigation(); ?>
  </main>
  <?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
