<?php get_header(); ?>
<div class="site-main">
  <main class="main-content">
    <?php $cat=get_queried_object(); ?>
    <div style="margin-bottom:24px;padding-bottom:14px;border-bottom:1px solid #e8e8e2;">
      <div class="post-cat" style="font-size:9px;margin-bottom:5px;"><?php single_cat_title(); ?></div>
      <?php if(category_description()): ?><p style="color:#999;font-size:14px;"><?php echo category_description(); ?></p><?php endif; ?>
    </div>
    <div class="posts-grid">
    <?php while(have_posts()): the_post(); ?>
    <div class="post-card">
      <?php if(has_post_thumbnail()): ?><div class="post-card-img"><a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('medium'); ?></a></div><?php endif; ?>
      <div class="post-card-body">
        <div class="post-meta"><span class="cat-link"><?php echo esc_html($cat->name); ?></span><span class="date"><?php echo get_the_date('d.m.Y'); ?></span></div>
        <a href="<?php the_permalink(); ?>" class="post-title"><?php the_title(); ?></a>
        <div class="post-excerpt"><?php the_excerpt(); ?></div>
      </div>
    </div>
    <?php endwhile; ?>
    </div>
    <?php the_posts_navigation(); ?>
  </main>
  <?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
