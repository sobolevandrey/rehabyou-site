<?php get_header(); ?>
<div class="site-main">
  <main class="main-content">
    <?php
    $paged = get_query_var('paged') ? get_query_var('paged') : 1;
    $args = ['posts_per_page' => 12, 'paged' => $paged];
    $query = new WP_Query($args);
    $first = true;
    ?>

    <?php while($query->have_posts()): $query->the_post(); ?>

    <?php if($first): $first = false; ?>
    <!-- Featured first post -->
    <div class="featured-post <?php echo has_post_thumbnail() ? '' : 'featured-no-img'; ?>">
      <?php if(has_post_thumbnail()): ?>
      <div class="featured-img">
        <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('large'); ?></a>
      </div>
      <?php endif; ?>
      <div class="featured-content">
        <?php $cats = get_the_category(); if($cats): ?>
        <div class="post-cat">
          <a href="<?php echo get_category_link($cats[0]->term_id); ?>"><?php echo esc_html($cats[0]->name); ?></a>
        </div>
        <?php endif; ?>
        <a href="<?php the_permalink(); ?>" class="post-title"><?php the_title(); ?></a>
        <div class="post-excerpt"><?php the_excerpt(); ?></div>
        <div class="post-meta"><?php echo get_the_date('d.m.Y'); ?></div>
      </div>
    </div>
    <div class="posts-grid">
    <?php else: ?>
    <!-- Grid posts -->
    <div class="post-card">
      <?php if(has_post_thumbnail()): ?>
      <div class="post-card-img">
        <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('medium_large'); ?></a>
      </div>
      <?php endif; ?>
      <div class="post-card-body">
        <?php $cats = get_the_category(); if($cats): ?>
        <div class="post-meta">
          <a href="<?php echo get_category_link($cats[0]->term_id); ?>" class="cat-link"><?php echo esc_html($cats[0]->name); ?></a>
          <span><?php echo get_the_date('d.m.Y'); ?></span>
        </div>
        <?php endif; ?>
        <a href="<?php the_permalink(); ?>" class="post-title"><?php the_title(); ?></a>
        <div class="post-excerpt"><?php the_excerpt(); ?></div>
      </div>
    </div>
    <?php endif; ?>
    <?php endwhile; ?>
    </div><!-- end posts-grid -->

    <?php if($query->max_num_pages > 1): ?>
    <div class="load-more-wrap">
      <?php if(get_next_posts_link(null, $query->max_num_pages)): ?>
        <?php next_posts_link('<span class="load-more">Загрузить ещё</span>', $query->max_num_pages); ?>
      <?php endif; ?>
    </div>
    <?php endif; wp_reset_postdata(); ?>
  </main>
  <?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
