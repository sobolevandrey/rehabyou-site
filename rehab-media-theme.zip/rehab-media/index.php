<?php get_header(); ?>
<div class="site-main">
  <main class="main-content">
    <?php
    $paged = get_query_var('paged') ?: 1;
    $args = ['posts_per_page' => 13, 'paged' => $paged,
             'category__not_in' => [get_cat_ID('Uncategorized')]];
    $query = new WP_Query($args);
    $i = 0;
    ?>
    <?php while($query->have_posts()): $query->the_post(); $i++; ?>

    <?php if($i === 1): // Featured ?>
    <div class="featured-post">
      <?php if(has_post_thumbnail()): ?>
      <div class="featured-img-full"><?php the_post_thumbnail('large'); ?></div>
      <?php endif; ?>
      <div class="featured-bg"></div>
      <div class="featured-content">
        <?php $cats = get_the_category(); if($cats): ?>
        <div class="post-cat"><a href="<?php echo get_category_link($cats[0]->term_id); ?>"><?php echo esc_html($cats[0]->name); ?></a></div>
        <?php endif; ?>
        <a href="<?php the_permalink(); ?>" class="post-title"><?php the_title(); ?></a>
        <div class="post-excerpt"><?php the_excerpt(); ?></div>
        <div class="post-meta"><?php echo get_the_date('d.m.Y'); ?></div>
      </div>
    </div>

    <?php // Telegram баннер после featured ?>
    <div class="tg-banner">
      <div class="tg-banner-text">
        <strong>Rehab.You в Telegram</strong>
        Советы по восстановлению, акции и новые статьи — подписывайтесь
      </div>
      <a href="https://t.me/+VMr5mZEITjJhMWQ6" target="_blank" class="tg-banner-btn">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12l-6.871 4.326-2.962-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.537-.194 1.006.131.833.941z"/></svg>
        Подписаться
      </a>
    </div>

    <div class="posts-grid">
    <?php else: // Grid ?>
    <div class="post-card">
      <?php if(has_post_thumbnail()): ?>
      <div class="post-card-img"><a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('medium'); ?></a></div>
      <?php endif; ?>
      <div class="post-card-body">
        <?php $cats = get_the_category(); if($cats): ?>
        <div class="post-meta">
          <a href="<?php echo get_category_link($cats[0]->term_id); ?>" class="cat-link"><?php echo esc_html($cats[0]->name); ?></a>
          <span class="date"><?php echo get_the_date('d.m.Y'); ?></span>
        </div>
        <?php endif; ?>
        <a href="<?php the_permalink(); ?>" class="post-title"><?php the_title(); ?></a>
        <div class="post-excerpt"><?php the_excerpt(); ?></div>
      </div>
    </div>
    <?php endif; ?>
    <?php endwhile; ?>
    </div>

    <?php if($query->max_num_pages > 1): ?>
    <div class="load-more-wrap">
      <?php next_posts_link('<span class="load-more">Загрузить ещё статьи</span>', $query->max_num_pages); ?>
    </div>
    <?php endif; wp_reset_postdata(); ?>
  </main>
  <?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
