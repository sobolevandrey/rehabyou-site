<?php get_header(); ?>
<div class="site-main">
  <main class="main-content">
    <?php
    $paged = get_query_var('paged') ?: 1;
    $q = new WP_Query(['posts_per_page'=>12,'paged'=>$paged,'category__not_in'=>[get_cat_ID('Uncategorized')]]);
    $i = 0;
    while($q->have_posts()): $q->the_post(); $i++;
    ?>
    <?php if($i===1): ?>
    <!-- Featured — фото на всю ширину, текст поверх -->
    <div class="featured-post <?php echo has_post_thumbnail()?'':'featured-no-img'; ?>">
      <?php if(has_post_thumbnail()): ?>
      <div class="featured-img-bg"><?php the_post_thumbnail('large'); ?></div>
      <div class="featured-overlay"></div>
      <?php endif; ?>
      <div class="featured-body">
        <?php $cats=get_the_category(); if($cats): ?>
        <div class="post-cat"><a href="<?php echo get_category_link($cats[0]->term_id); ?>"><?php echo esc_html($cats[0]->name); ?></a></div>
        <?php endif; ?>
        <a href="<?php the_permalink(); ?>" class="post-title"><?php the_title(); ?></a>
        <div class="post-excerpt"><?php the_excerpt(); ?></div>
        <div class="post-meta"><?php echo get_the_date('d.m.Y'); ?></div>
      </div>
    </div>
    <div class="posts-grid">
    <?php else: ?>
    <div class="post-card">
      <?php if(has_post_thumbnail()): ?>
      <div class="post-card-img"><a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('medium'); ?></a></div>
      <?php endif; ?>
      <div class="post-card-body">
        <?php $cats=get_the_category(); if($cats): ?>
        <div class="post-meta">
          <a href="<?php echo get_category_link($cats[0]->term_id); ?>" class="cat-link"><?php echo esc_html($cats[0]->name); ?></a>
          <span class="date"><?php echo get_the_date('d.m.Y'); ?></span>
        </div>
        <?php endif; ?>
        <a href="<?php the_permalink(); ?>" class="post-title"><?php the_title(); ?></a>
        <div class="post-excerpt"><?php the_excerpt(); ?></div>
      </div>
    </div>
    <?php endif; ?>
    <?php endwhile; ?>
    </div>
    <?php if($q->max_num_pages>1): ?>
    <div class="load-more-wrap"><?php next_posts_link('<span class="load-more">Загрузить ещё</span>', $q->max_num_pages); ?></div>
    <?php endif; wp_reset_postdata(); ?>
  </main>
  <?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
