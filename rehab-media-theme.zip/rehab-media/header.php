<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<header class="site-header">
  <div class="header-inner">
    <a href="<?php echo home_url('/'); ?>" class="site-logo">
      REHAB<span>.</span>YOU MEDIA
    </a>
    <nav>
      <?php wp_nav_menu(['theme_location' => 'primary', 'container' => false, 'menu_class' => 'header-nav', 'fallback_cb' => 'rehab_category_menu']); ?>
    </nav>
    <a href="https://n1276048.yclients.com" target="_blank" class="header-cta">Записаться на массаж</a>
  </div>
</header>
<?php
function rehab_category_menu() {
    $cats = get_categories(['hide_empty' => false]);
    echo '<ul class="header-nav">';
    foreach($cats as $cat) {
        echo '<li><a href="' . get_category_link($cat->term_id) . '">' . esc_html($cat->name) . '</a></li>';
    }
    echo '</ul>';
}
?>
