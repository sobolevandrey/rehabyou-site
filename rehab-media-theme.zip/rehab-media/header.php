<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<header class="site-header">
  <div class="header-top">
    <a href="<?php echo home_url('/'); ?>" class="site-logo">REHAB<span class="dot">.</span>YOU MEDIA</a>
    <nav>
      <ul class="header-nav">
        <?php
        $cats = get_categories(['hide_empty' => false, 'exclude' => get_cat_ID('Uncategorized')]);
        foreach($cats as $cat):
            $active = (is_category($cat->term_id)) ? ' class="current-cat"' : '';
            echo '<li' . $active . '><a href="' . get_category_link($cat->term_id) . '">' . esc_html($cat->name) . '</a></li>';
        endforeach; ?>
      </ul>
    </nav>
    <a href="https://t.me/+VMr5mZEITjJhMWQ6" target="_blank" class="header-tg">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12l-6.871 4.326-2.962-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.537-.194 1.006.131.833.941z"/></svg>
      <span>Telegram</span>
    </a>
  </div>
</header>
