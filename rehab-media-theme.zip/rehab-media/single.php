<?php get_header(); ?>
<div class="single-header">
  <?php $cats = get_the_category(); if($cats): ?>
  <div class="post-cat"><a href="<?php echo get_category_link($cats[0]->term_id); ?>"><?php echo esc_html($cats[0]->name); ?></a></div>
  <?php endif; ?>
  <h1><?php the_title(); ?></h1>
  <div class="post-meta"><?php echo get_the_date('d F Y'); ?></div>
</div>

<?php if(has_post_thumbnail()): ?>
<div class="single-featured-img"><?php the_post_thumbnail('large'); ?></div>
<?php endif; ?>

<div class="single-wrap">
  <div class="entry-content">
    <?php the_content(); ?>

    <div class="post-cta-block">
      <div>
        <div class="eyebrow">Rehab.You · Москва</div>
        <strong>Тело скажет спасибо уже после первого сеанса</strong>
        <p>Два клуба, 18 мастеров, запись онлайн за минуту</p>
      </div>
      <a href="https://n1276048.yclients.com" target="_blank" class="cta-link">Записаться</a>
    </div>
  </div>
  <?php get_sidebar(); ?>
</div>

<!-- Похожие статьи -->
<?php
$current_cats = wp_get_post_categories(get_the_ID());
$related = new WP_Query([
    'category__in' => $current_cats, 'post__not_in' => [get_the_ID()],
    'posts_per_page' => 3, 'orderby' => 'rand'
]);
if($related->have_posts()): ?>
<div class="related-posts">
  <div class="related-title">Читайте также</div>
  <div class="related-grid">
    <?php while($related->have_posts()): $related->the_post(); ?>
    <a href="<?php the_permalink(); ?>" class="related-card">
      <?php if(has_post_thumbnail()): ?>
      <div class="related-card-img"><?php the_post_thumbnail('medium'); ?></div>
      <?php endif; ?>
      <div class="related-card-title"><?php the_title(); ?></div>
    </a>
    <?php endwhile; wp_reset_postdata(); ?>
  </div>
</div>
<?php endif; ?>

<div class="comments-area">
  <?php comments_template(); ?>
</div>
<?php get_footer(); ?>
