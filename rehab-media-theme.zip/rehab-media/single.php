<?php get_header(); ?>
<article class="single-article">
  <div class="single-header">
    <?php $cats = get_the_category(); if($cats): ?>
    <div class="post-cat">
      <a href="<?php echo get_category_link($cats[0]->term_id); ?>"><?php echo esc_html($cats[0]->name); ?></a>
    </div>
    <?php endif; ?>
    <h1><?php the_title(); ?></h1>
    <div class="post-meta">
      <span><?php echo get_the_date('d F Y'); ?></span>
    </div>
  </div>

  <?php if(has_post_thumbnail()): ?>
  <div class="single-featured-img">
    <?php the_post_thumbnail('large'); ?>
  </div>
  <?php endif; ?>

  <div class="entry-content">
    <?php the_content(); ?>

    <!-- CTA блок в конце каждой статьи -->
    <div class="post-cta-block">
      <div class="cta-text">
        <div class="eyebrow">Rehab.You · Москва</div>
        <strong>Тело скажет спасибо после первого сеанса</strong>
        <p>Два клуба, 18 мастеров, запись за минуту</p>
      </div>
      <a href="https://n1276048.yclients.com" target="_blank" class="cta-link">Записаться</a>
    </div>
  </div>
</article>
<?php get_footer(); ?>
