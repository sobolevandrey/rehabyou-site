<?php get_header(); ?>

<?php
$has_thumb = has_post_thumbnail();
$cats = get_the_category();
$cat_slug = $cats ? $cats[0]->slug : '';
$author_id = get_the_author_meta('ID');
$author_name = get_the_author_meta('display_name');
$author_bio = get_the_author_meta('description');
$author_avatar = get_avatar_url($author_id, ['size' => 64]);

// Контекстный CTA по рубрике
$cta_map = [
  'sport'          => ['Бежите марафон? Тело надо готовить.',    'Спортивный массаж за 48 часов до старта снижает риск травм и ускоряет восстановление.', 'Записаться на спортивный'],
  'krasota'        => ['Уход за собой — это не только снаружи.',  'Лимфодренажный и расслабляющий массаж — часть любой грамотной бьюти-рутины.',          'Записаться на массаж'],
  'materinstvo'    => ['Восстановление после родов — это работа.', 'Деликатный массаж помогает телу вернуться в ресурс быстрее.',                           'Записаться'],
  'telo-i-zdorovye'=> ['Тело держит всё что накопилось за неделю.','Один сеанс массажа — и напряжение уходит. Два клуба в Москве, запись онлайн.',         'Записаться сейчас'],
  'moskva'         => ['Москва выматывает. Тело это чувствует.',   'Восстанавливайтесь правильно — массаж в клубе рядом с вами.',                           'Записаться онлайн'],
  'sobytiya'       => ['Насыщенные выходные — напряжённое тело.',  'Классический или расслабляющий массаж вернёт ресурс за один сеанс.',                    'Записаться'],
];

$cta = $cta_map[$cat_slug] ?? [
  'Тело скажет спасибо уже после первого сеанса.',
  'Два клуба в Москве, 18 мастеров, запись онлайн за минуту.',
  'Записаться'
];
?>

<?php if($has_thumb): ?>
<div class="single-hero" id="singleHero">
  <div class="single-hero-bg" id="singleHeroBg"><?php the_post_thumbnail('full'); ?></div>
  <div class="single-hero-overlay"></div>
  <div class="single-hero-content">
    <div class="single-hero-inner">
      <?php if($cats): ?>
      <div class="post-cat"><a href="<?php echo get_category_link($cats[0]->term_id); ?>"><?php echo esc_html($cats[0]->name); ?></a></div>
      <?php endif; ?>
      <h1><?php the_title(); ?></h1>
    </div>
  </div>
</div>
<?php else: ?>
<div class="single-header-plain">
  <div class="single-header-inner">
    <?php if($cats): ?>
    <div class="post-cat"><a href="<?php echo get_category_link($cats[0]->term_id); ?>"><?php echo esc_html($cats[0]->name); ?></a></div>
    <?php endif; ?>
    <h1><?php the_title(); ?></h1>
  </div>
</div>
<?php endif; ?>

<!-- Byline -->
<div class="single-byline">
  <div class="single-byline-inner">
    <img src="<?php echo esc_url($author_avatar); ?>" alt="" class="byline-avatar">
    <span class="byline-name"><?php echo esc_html($author_name); ?></span>
    <span class="byline-sep">·</span>
    <span class="byline-date"><?php echo get_the_date('d F Y'); ?></span>
  </div>
</div>

<!-- Sticky мобильный бар -->
<div class="sticky-cta" id="stickyCta">
  <div class="sticky-cta-text"><?php echo esc_html($cta[0]); ?></div>
  <a href="https://n1276048.yclients.com" target="_blank" class="sticky-cta-btn"><?php echo esc_html($cta[2]); ?></a>
</div>

<div class="single-article">
  <div class="single-wrap">
    <div class="entry-content">
      <?php the_content(); ?>

      <?php if($author_bio): ?>
      <div class="author-card">
        <img src="<?php echo esc_url($author_avatar); ?>" alt="<?php echo esc_attr($author_name); ?>" class="author-card-avatar">
        <div class="author-card-info">
          <div class="author-card-label">Автор</div>
          <div class="author-card-name"><?php echo esc_html($author_name); ?></div>
          <div class="author-card-bio"><?php echo esc_html($author_bio); ?></div>
        </div>
      </div>
      <?php endif; ?>

      <!-- Контекстный CTA блок в тексте -->
      <div class="post-cta-block">
        <div>
          <div class="eyebrow">Rehab.You · Москва</div>
          <strong><?php echo esc_html($cta[0]); ?></strong>
          <p><?php echo esc_html($cta[1]); ?></p>
        </div>
        <a href="https://n1276048.yclients.com" target="_blank" class="cta-link"><?php echo esc_html($cta[2]); ?></a>
      </div>
    </div>
    <?php get_sidebar(); ?>
  </div>

  <?php
  $cat_ids = wp_get_post_categories(get_the_ID());
  $rel = new WP_Query(['category__in'=>$cat_ids,'post__not_in'=>[get_the_ID()],'posts_per_page'=>3,'orderby'=>'rand']);
  if($rel->have_posts()): ?>
  <div class="related-posts">
    <div class="related-title">Читайте также</div>
    <div class="related-grid">
      <?php while($rel->have_posts()): $rel->the_post(); ?>
      <a href="<?php the_permalink(); ?>" class="related-card">
        <?php if(has_post_thumbnail()): ?><div class="related-card-img"><?php the_post_thumbnail('medium'); ?></div><?php endif; ?>
        <div class="related-card-cat"><?php $rc=get_the_category(); if($rc) echo esc_html($rc[0]->name); ?></div>
        <div class="related-card-title"><?php the_title(); ?></div>
      </a>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>
  </div>
  <?php endif; ?>

  <div class="comments-area"><?php comments_template(); ?></div>
</div>

<script>
// Parallax
(function(){
  var hero = document.getElementById('singleHero');
  var bg = document.getElementById('singleHeroBg');
  if(!hero || !bg) return;
  window.addEventListener('scroll', function() {
    var s = window.pageYOffset;
    if(s < hero.offsetHeight + 200)
      bg.style.transform = 'translateY(' + (s * 0.35) + 'px)';
  }, {passive:true});
})();

// Sticky CTA — появляется после 40% статьи
(function(){
  var bar = document.getElementById('stickyCta');
  if(!bar) return;
  var shown = false;
  window.addEventListener('scroll', function() {
    var scrolled = window.pageYOffset;
    var docH = document.body.scrollHeight - window.innerHeight;
    var pct = scrolled / docH;
    if(pct > 0.15 && !shown) {
      bar.classList.add('visible');
      shown = true;
    }
    // Скрываем когда добрались до комментариев
    var comments = document.querySelector('.comments-area');
    if(comments) {
      var commentsTop = comments.getBoundingClientRect().top;
      if(commentsTop < window.innerHeight * 0.8) {
        bar.classList.remove('visible');
      } else if(shown) {
        bar.classList.add('visible');
      }
    }
  }, {passive:true});
})();
</script>

<?php get_footer(); ?>
