<?php get_header(); ?>

<?php
$has_thumb = has_post_thumbnail();
$cats = get_the_category();
?>

<?php if($has_thumb): ?>
<!-- HERO: фото на всю ширину с parallax, заголовок поверх -->
<div class="single-hero" id="singleHero">
  <div class="single-hero-bg" id="singleHeroBg">
    <?php the_post_thumbnail('full'); ?>
  </div>
  <div class="single-hero-overlay"></div>
  <div class="single-hero-content">
    <div class="single-hero-inner">
      <?php if($cats): ?>
      <div class="post-cat"><a href="<?php echo get_category_link($cats[0]->term_id); ?>"><?php echo esc_html($cats[0]->name); ?></a></div>
      <?php endif; ?>
      <h1><?php the_title(); ?></h1>
      <div class="single-hero-meta"><?php echo get_the_date('d F Y'); ?></div>
    </div>
  </div>
</div>

<?php else: ?>
<!-- Без фото — обычный заголовок -->
<div class="single-header-plain">
  <div class="single-header-inner">
    <?php if($cats): ?>
    <div class="post-cat"><a href="<?php echo get_category_link($cats[0]->term_id); ?>"><?php echo esc_html($cats[0]->name); ?></a></div>
    <?php endif; ?>
    <h1><?php the_title(); ?></h1>
    <div class="post-meta date"><?php echo get_the_date('d F Y'); ?></div>
  </div>
</div>
<?php endif; ?>

<!-- Контент + сайдбар -->
<div class="single-article">
  <div class="single-wrap">
    <div class="entry-content">
      <?php the_content(); ?>
      <div class="post-cta-block">
        <div>
          <div class="eyebrow">Rehab.You · Москва</div>
          <strong>Тело скажет спасибо уже после первого сеанса</strong>
          <p>Два клуба, 18 мастеров, запись за минуту</p>
        </div>
        <a href="https://n1276048.yclients.com" target="_blank" class="cta-link">Записаться</a>
      </div>
    </div>
    <?php get_sidebar(); ?>
  </div>

  <?php
  $cat_ids = wp_get_post_categories(get_the_ID());
  $rel = new WP_Query(['category__in'=>$cat_ids,'post__not_in'=>[get_the_ID()],'posts_per_page'=>3,'orderby'=>'rand']);
  if($rel->have_posts()): ?>
  <div class="related-posts">
    <div class="related-title">Читайте также</div>
    <div class="related-grid">
      <?php while($rel->have_posts()): $rel->the_post(); ?>
      <a href="<?php the_permalink(); ?>" class="related-card">
        <?php if(has_post_thumbnail()): ?><div class="related-card-img"><?php the_post_thumbnail('medium'); ?></div><?php endif; ?>
        <div class="related-card-title"><?php the_title(); ?></div>
      </a>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>
  </div>
  <?php endif; ?>

  <div class="comments-area"><?php comments_template(); ?></div>
</div>

<script>
// Parallax эффект для hero фото
(function(){
  var hero = document.getElementById('singleHero');
  var bg = document.getElementById('singleHeroBg');
  if(!hero || !bg) return;
  function onScroll() {
    var scrolled = window.pageYOffset;
    var heroH = hero.offsetHeight;
    if(scrolled < heroH + 200) {
      bg.style.transform = 'translateY(' + (scrolled * 0.35) + 'px)';
    }
  }
  window.addEventListener('scroll', onScroll, {passive: true});
})();
</script>

<?php get_footer(); ?>
