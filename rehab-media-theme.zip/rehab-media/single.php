<?php get_header(); ?>

<?php
$has_thumb = has_post_thumbnail();
$cats = get_the_category();
$cat_slug = $cats ? $cats[0]->slug : '';
$author_id = get_the_author_meta('ID');
$author_name = get_the_author_meta('display_name');
$author_bio = get_the_author_meta('description');
$author_avatar = get_avatar_url($author_id, ['size' => 64]);

$cta_map = [
  'sport'           => ['Бежите марафон? Тело надо готовить.', 'Спортивный массаж за 48 часов до старта снижает риск травм и ускоряет восстановление.', 'Записаться на спортивный', 'https://rehabyou.site/massage/sport/?utm_source=blog&utm_medium=article&utm_campaign=sport'],
  'krasota'         => ['Уход за собой — это не только снаружи.', 'Расслабляющий и лимфодренажный массаж — часть любой грамотной бьюти-рутины.', 'Записаться на массаж', 'https://rehabyou.site/massage/relax/?utm_source=blog&utm_medium=article&utm_campaign=beauty'],
  'materinstvo'     => ['Восстановление после родов — это работа.', 'Деликатный массаж помогает телу вернуться в ресурс быстрее. Два клуба в Москве.', 'Записаться', 'https://rehabyou.site/?utm_source=blog&utm_medium=article&utm_campaign=maternity'],
  'telo-i-zdorovye' => ['Тело держит всё что накопилось за неделю.', 'Один сеанс — и напряжение уходит. Классический или спортивный массаж в клубе рядом.', 'Записаться сейчас', 'https://rehabyou.site/massage/classic/?utm_source=blog&utm_medium=article&utm_campaign=health'],
  'moskva'          => ['Москва выматывает. Тело это чувствует.', 'Восстанавливайтесь правильно — массаж в клубе рядом с вами. Два адреса в центре.', 'Записаться онлайн', 'https://rehabyou.site/?utm_source=blog&utm_medium=article&utm_campaign=moscow'],
  'sobytiya'        => ['Насыщенные выходные — напряжённое тело.', 'Классический или расслабляющий массаж вернёт ресурс за один сеанс.', 'Записаться', 'https://rehabyou.site/?utm_source=blog&utm_medium=article&utm_campaign=events'],
];

$cta = $cta_map[$cat_slug] ?? [
  'Тело скажет спасибо уже после первого сеанса.',
  'Два клуба в Москве, 18 мастеров, запись за минуту.',
  'Записаться',
  'https://rehabyou.site/?utm_source=blog&utm_medium=article&utm_campaign=general'
];
?>

<?php if($has_thumb): ?>
<div class="single-hero" id="singleHero">
  <div class="single-hero-bg" id="singleHeroBg"><?php the_post_thumbnail('full'); ?></div>
  <div class="single-hero-overlay"></div>
  <div class="single-hero-content">
    <div class="single-hero-inner">
      <?php if($cats): ?>
      <div class="post-cat"><a href="<?php echo get_category_link($cats[0]->term_id); ?>"><?php echo esc_html($cats[0]->name); ?></a></div>
      <?php endif; ?>
      <h1><?php the_title(); ?></h1>
    </div>
  </div>
</div>
<?php else: ?>
<div class="single-header-plain">
  <div class="single-header-inner">
    <?php if($cats): ?>
    <div class="post-cat"><a href="<?php echo get_category_link($cats[0]->term_id); ?>"><?php echo esc_html($cats[0]->name); ?></a></div>
    <?php endif; ?>
    <h1><?php the_title(); ?></h1>
  </div>
</div>
<?php endif; ?>

<!-- Byline -->
<div class="single-byline">
  <div class="single-byline-inner">
    <img src="<?php echo esc_url($author_avatar); ?>" alt="" class="byline-avatar">
    <span class="byline-name"><?php echo esc_html($author_name); ?></span>
    <span class="byline-sep">·</span>
    <span class="byline-date"><?php echo get_the_date('d F Y'); ?></span>
  </div>
</div>

<!-- Sticky бар — вне потока страницы, fixed через CSS -->
<div class="sticky-cta" id="stickyCta">
  <div class="sticky-cta-text"><?php echo esc_html($cta[0]); ?></div>
  <a href="<?php echo esc_url($cta[3]); ?>" target="_blank" rel="noopener" class="sticky-cta-btn"><?php echo esc_html($cta[2]); ?></a>
</div>

<div class="single-article">
  <div class="single-wrap">
    <div class="entry-content">
      <?php the_content(); ?>

      <?php if($author_bio): ?>
      <div class="author-card">
        <img src="<?php echo esc_url($author_avatar); ?>" alt="<?php echo esc_attr($author_name); ?>" class="author-card-avatar">
        <div class="author-card-info">
          <div class="author-card-label">Автор</div>
          <div class="author-card-name"><?php echo esc_html($author_name); ?></div>
          <div class="author-card-bio"><?php echo esc_html($author_bio); ?></div>
        </div>
      </div>
      <?php endif; ?>

      <div class="post-cta-block">
        <div>
          <div class="eyebrow">Rehab.You · Москва</div>
          <strong><?php echo esc_html($cta[0]); ?></strong>
          <p><?php echo esc_html($cta[1]); ?></p>
        </div>
        <a href="<?php echo esc_url($cta[3]); ?>" target="_blank" rel="noopener" class="cta-link"><?php echo esc_html($cta[2]); ?></a>
      </div>
    </div>
    <?php get_sidebar(); ?>
  </div>

  <?php
  $cat_ids = wp_get_post_categories(get_the_ID());
  $rel = new WP_Query(['category__in'=>$cat_ids,'post__not_in'=>[get_the_ID()],'posts_per_page'=>3,'orderby'=>'rand']);
  if($rel->have_posts()): ?>
  <div class="related-posts">
    <div class="related-title">Читайте также</div>
    <div class="related-grid">
      <?php while($rel->have_posts()): $rel->the_post(); ?>
      <a href="<?php the_permalink(); ?>" class="related-card">
        <?php if(has_post_thumbnail()): ?><div class="related-card-img"><?php the_post_thumbnail('medium'); ?></div><?php endif; ?>
        <div class="related-card-cat"><?php $rc=get_the_category(); if($rc) echo esc_html($rc[0]->name); ?></div>
        <div class="related-card-title"><?php the_title(); ?></div>
      </a>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>
  </div>
  <?php endif; ?>

  <div class="comments-area"><?php comments_template(); ?></div>
</div>

<script>
(function(){
  var hero = document.getElementById('singleHero');
  var bg = document.getElementById('singleHeroBg');
  if(hero && bg) {
    window.addEventListener('scroll', function() {
      var s = window.pageYOffset;
      if(s < hero.offsetHeight + 200)
        bg.style.transform = 'translateY(' + (s * 0.35) + 'px)';
    }, {passive:true});
  }

  // Sticky bar — только мобилка
  if(window.innerWidth > 700) return;
  var bar = document.getElementById('stickyCta');
  if(!bar) return;
  var shown = false;
  window.addEventListener('scroll', function() {
    var scrollPct = window.pageYOffset / (document.body.scrollHeight - window.innerHeight);
    var comments = document.querySelector('.comments-area');
    var nearEnd = comments && comments.getBoundingClientRect().top < window.innerHeight;
    if(scrollPct > 0.15 && !nearEnd) {
      if(!shown) { bar.classList.add('visible'); shown = true; }
    } else {
      if(shown && nearEnd) bar.classList.remove('visible');
    }
  }, {passive:true});
})();
</script>

<?php get_footer(); ?>
