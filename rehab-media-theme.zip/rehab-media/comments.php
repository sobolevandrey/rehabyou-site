<?php if(post_password_required()) return; ?>
<?php if(have_comments()): ?>
<h3 class="comments-title"><?php comments_number('Нет комментариев', '1 комментарий', '% комментариев'); ?></h3>
<ul class="comment-list">
  <?php wp_list_comments(['style' => 'ul', 'short_ping' => true,
    'callback' => function($comment, $args, $depth) { ?>
    <li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
      <div class="comment">
        <div class="comment-meta">
          <span class="author"><?php echo get_comment_author(); ?></span>
          <?php echo get_comment_date('d.m.Y'); ?>
        </div>
        <div class="comment-body"><?php comment_text(); ?></div>
      </div>
    <?php }]); ?>
</ul>
<?php endif; ?>
<?php comment_form(['title_reply' => 'Оставить комментарий',
  'label_submit' => 'Отправить',
  'comment_field' => '<div class="comment-form-comment"><label for="comment">Комментарий</label><textarea id="comment" name="comment" rows="5" required></textarea></div>',
  'fields' => [
    'author' => '<div class="comment-form-author"><label for="author">Имя</label><input id="author" name="author" type="text" required></div>',
    'email' => '<div class="comment-form-email"><label for="email">Email</label><input id="email" name="email" type="email" required></div>',
    'url' => '', 'cookies' => '',
  ],
]); ?>
